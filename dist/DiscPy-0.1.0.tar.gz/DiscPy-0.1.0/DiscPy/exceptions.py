class DiscuitAPIException(Exception):
    pass