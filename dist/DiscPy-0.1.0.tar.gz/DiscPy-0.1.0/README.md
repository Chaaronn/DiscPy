# BiscuitWrapper

A wrapper for the Dicsuit API.